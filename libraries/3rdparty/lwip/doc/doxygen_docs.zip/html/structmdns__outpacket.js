var structmdns__outpacket =
[
    [ "additional", "structmdns__outpacket.html#acda83121a9bb785d20f979a0a3a312ce", null ],
    [ "answers", "structmdns__outpacket.html#aad2c24d4d5a935a209966ceace82f9ad", null ],
    [ "authoritative", "structmdns__outpacket.html#a1a689ea7094a3569878f15477e725035", null ],
    [ "cache_flush", "structmdns__outpacket.html#a9bd0fd91dda48baa2938dddd747d3195", null ],
    [ "dest_addr", "structmdns__outpacket.html#a1fdc90b48d8cf1fc24895f0c7a5798e4", null ],
    [ "domain_offsets", "structmdns__outpacket.html#aee97e98c4869aa63ffe348d38d87221f", null ],
    [ "legacy_query", "structmdns__outpacket.html#aff8c520bffa87c78e0ee2440571bbd65", null ],
    [ "netif", "structmdns__outpacket.html#ad0bd066f127d35a0ce67193e1cd07430", null ],
    [ "pbuf", "structmdns__outpacket.html#a83d4504736f2bf315fc8b712c6a446e9", null ],
    [ "questions", "structmdns__outpacket.html#a0d402cde040728d361dec8f7d86f504c", null ],
    [ "tx_id", "structmdns__outpacket.html#ac470f02a9f332f18e027437dc293d348", null ],
    [ "unicast_reply", "structmdns__outpacket.html#a68255725575af086a3afa76bc5c8e64d", null ],
    [ "write_offset", "structmdns__outpacket.html#a8ead21e392b21c3e872c0cab874cdcf5", null ]
];