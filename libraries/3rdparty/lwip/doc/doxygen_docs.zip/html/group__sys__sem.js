var group__sys__sem =
[
    [ "sys_arch_sem_wait", "group__sys__sem.html#ga8d364c5037778acb21c3df675db81b4f", null ],
    [ "sys_sem_free", "group__sys__sem.html#ga83b781f96c30e915c752065a757da283", null ],
    [ "sys_sem_new", "group__sys__sem.html#gaf99da9e34a71855285c535183133dfde", null ],
    [ "sys_sem_set_invalid", "group__sys__sem.html#ga42a2ab32afbf41a4146a9d135224ef33", null ],
    [ "sys_sem_signal", "group__sys__sem.html#gaaf800273061fcc3f8200fd4e1b9ca875", null ],
    [ "sys_sem_valid", "group__sys__sem.html#ga09a6c052ddaf799139efc56adfa087e4", null ]
];