var structzepif__init =
[
    [ "addr", "structzepif__init.html#a5a9a7ee6e687a7c1ae85b103d39de61d", null ],
    [ "zep_dst_ip_addr", "structzepif__init.html#a851efb99a973348f1064a31b97ce779d", null ],
    [ "zep_dst_udp_port", "structzepif__init.html#a86c6229ed3010158e601666afe91a286", null ],
    [ "zep_netif", "structzepif__init.html#a3d97bf90b6bd4dd8258a3b1caf7890e3", null ],
    [ "zep_src_ip_addr", "structzepif__init.html#adbe989f1f5cba623d742187def36f02c", null ],
    [ "zep_src_udp_port", "structzepif__init.html#ad739032585841b126b4c0eab5899d40f", null ]
];