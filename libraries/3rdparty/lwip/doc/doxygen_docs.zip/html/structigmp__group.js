var structigmp__group =
[
    [ "group_address", "structigmp__group.html#ae26e6041f865880bf46cd21b6f9af854", null ],
    [ "group_state", "structigmp__group.html#add0d24f719ad4b598abad254689ad911", null ],
    [ "last_reporter_flag", "structigmp__group.html#a8fa72062d168d81c1c5ae5209eb0a874", null ],
    [ "next", "structigmp__group.html#a95c41b9e7de6a14bb8a7910913395e78", null ],
    [ "timer", "structigmp__group.html#a8e2227e486652603fcd7f88681d4c75b", null ],
    [ "use", "structigmp__group.html#ab3625aeb3689e3626f73138eb0e41852", null ]
];