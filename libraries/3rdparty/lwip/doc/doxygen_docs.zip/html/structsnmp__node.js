var structsnmp__node =
[
    [ "node_type", "structsnmp__node.html#a1af8e20a688943a419b307bf123b1851", null ],
    [ "oid", "structsnmp__node.html#ae7a3bb0eb49ac527d461be414937f271", null ]
];