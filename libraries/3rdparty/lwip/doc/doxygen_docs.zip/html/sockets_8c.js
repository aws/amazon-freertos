var sockets_8c =
[
    [ "sockaddr_aligned", "unionsockaddr__aligned.html", null ],
    [ "lwip_pollscan_opts", "sockets_8c.html#a2f15a466e75cbaaea0c31e63116870f9", [
      [ "LWIP_POLLSCAN_CLEAR", "sockets_8c.html#a2f15a466e75cbaaea0c31e63116870f9aa9a8fe3199d00016f1f5ad639e1b28f7", null ],
      [ "LWIP_POLLSCAN_INC_WAIT", "sockets_8c.html#a2f15a466e75cbaaea0c31e63116870f9ab6511d3104f70c18fb4bd80f24cb867d", null ],
      [ "LWIP_POLLSCAN_DEC_WAIT", "sockets_8c.html#a2f15a466e75cbaaea0c31e63116870f9a6c1eefa3e29a39b923c4b522eb1b3eb1", null ]
    ] ],
    [ "lwip_fcntl", "sockets_8c.html#ae84296093574ec746f8f88321356388f", null ],
    [ "lwip_listen", "sockets_8c.html#abee6ee286147cf334a1ba19f19b2e08b", null ],
    [ "lwip_shutdown", "sockets_8c.html#ade85c68b6673296c8fb67127b93fa4c1", null ],
    [ "lwip_socket_thread_cleanup", "sockets_8c.html#ab8cd92b10dbe3fb33da03faed1ea98a7", null ],
    [ "lwip_socket_thread_init", "sockets_8c.html#a0a250b3b4d1827e3a3661327f5e80ae0", null ]
];