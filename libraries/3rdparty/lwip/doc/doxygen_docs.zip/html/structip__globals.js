var structip__globals =
[
    [ "current_input_netif", "structip__globals.html#a7da899c663b1d560b61d92ba6d544701", null ],
    [ "current_ip4_header", "structip__globals.html#a2e810f97cf3e8e855e3baafc3be8c0d4", null ],
    [ "current_ip6_header", "structip__globals.html#aa5cfc3ac29dc746a4cbe844206b0ed41", null ],
    [ "current_ip_header_tot_len", "structip__globals.html#a17004526e6f1a164c0bab01aeac5e34a", null ],
    [ "current_iphdr_dest", "structip__globals.html#a0b4e54250c692c638408de54593d2aa1", null ],
    [ "current_iphdr_src", "structip__globals.html#a04d85a3dc2c417050b3e088fa58a74b0", null ],
    [ "current_netif", "structip__globals.html#a7803dc5950d143e4433a0df689989bab", null ]
];