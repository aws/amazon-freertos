var structaltcp__allocator__s =
[
    [ "alloc", "structaltcp__allocator__s.html#aaf07ebf181a11d0320381ef46d40e687", null ],
    [ "arg", "structaltcp__allocator__s.html#a8d8aa48e9a105e9d25ad4b90d259d0b1", null ]
];