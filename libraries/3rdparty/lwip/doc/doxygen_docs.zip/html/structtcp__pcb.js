var structtcp__pcb =
[
    [ "local_ip", "structtcp__pcb.html#a0c4f101d55debee0d8fad86a7eb4f76f", null ],
    [ "next", "structtcp__pcb.html#a2aed7ffb5fb83aabe68b36f097d99260", null ]
];