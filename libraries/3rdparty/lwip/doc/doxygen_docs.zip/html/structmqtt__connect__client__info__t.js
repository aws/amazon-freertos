var structmqtt__connect__client__info__t =
[
    [ "client_id", "structmqtt__connect__client__info__t.html#ad35f7850df21f001d5c5ffaa1a18c05a", null ],
    [ "client_pass", "structmqtt__connect__client__info__t.html#a8f68efe91c5311418151256c96102d4b", null ],
    [ "client_user", "structmqtt__connect__client__info__t.html#aec961673d5c3e8dc853c91f30d9333b5", null ],
    [ "keep_alive", "structmqtt__connect__client__info__t.html#ac80262a7456812e9eefffd8c3b9ac21a", null ],
    [ "tls_config", "structmqtt__connect__client__info__t.html#a45987acc116de5d27fff6856778e55b4", null ],
    [ "will_msg", "structmqtt__connect__client__info__t.html#a925fcebd15555afdc0820e196e2fd3a7", null ],
    [ "will_qos", "structmqtt__connect__client__info__t.html#a07954934f4fecf54fa190997848229d9", null ],
    [ "will_retain", "structmqtt__connect__client__info__t.html#a49c10873f44d7534140a63eef2a6a4e3", null ],
    [ "will_topic", "structmqtt__connect__client__info__t.html#a32e77415460752ba0484eb3ba0faf0c8", null ]
];