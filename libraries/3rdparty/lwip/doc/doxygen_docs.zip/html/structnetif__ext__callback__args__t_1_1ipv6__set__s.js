var structnetif__ext__callback__args__t_1_1ipv6__set__s =
[
    [ "addr_index", "structnetif__ext__callback__args__t_1_1ipv6__set__s.html#ad44a5f52ad695ea90b15a1e29ff823dd", null ],
    [ "old_address", "structnetif__ext__callback__args__t_1_1ipv6__set__s.html#aafda237ad0c20d25fa2ad83d63051226", null ]
];