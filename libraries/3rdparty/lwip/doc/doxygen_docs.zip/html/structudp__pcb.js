var structudp__pcb =
[
    [ "chksum_len_rx", "structudp__pcb.html#a5e2833df51760c83c6032608eb5d0d4d", null ],
    [ "local_ip", "structudp__pcb.html#a6160ea5e52f0d33e51b16b853ea1cd63", null ],
    [ "local_port", "structudp__pcb.html#a8cc805631142eefc5593ae8ba3302d7c", null ],
    [ "mcast_ifindex", "structudp__pcb.html#ac80ae56333b88cea08bfa3563b0dd3cd", null ],
    [ "mcast_ip4", "structudp__pcb.html#a1c32c7ebd76898cf8f1227c10d34dbe0", null ],
    [ "mcast_ttl", "structudp__pcb.html#aaab9255f7f1186aef12d45c9bb90d3f4", null ],
    [ "recv", "structudp__pcb.html#ac05dee75a3d6666267f7e626c2ec56a8", null ],
    [ "recv_arg", "structudp__pcb.html#a11e4c40b8868aa40d923756a60598cab", null ]
];