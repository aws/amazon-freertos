var structip__addr =
[
    [ "type", "structip__addr.html#a66eaa8e9051e7102bf9f0c195fbe555a", null ]
];