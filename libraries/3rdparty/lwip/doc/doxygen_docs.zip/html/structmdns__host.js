var structmdns__host =
[
    [ "dns_ttl", "structmdns__host.html#a4547e5a8375fc1f1372546268a80d51b", null ],
    [ "name", "structmdns__host.html#a560447b364854eb5480e137e09d3cd24", null ],
    [ "probes_sent", "structmdns__host.html#ac8f6e3c6e1251bf73f043e489c840922", null ],
    [ "probing_state", "structmdns__host.html#af9ced31c35de6a281e5b13f01e5aae61", null ],
    [ "services", "structmdns__host.html#a750c31340c22e51375e4dc3e6e94f2ed", null ]
];