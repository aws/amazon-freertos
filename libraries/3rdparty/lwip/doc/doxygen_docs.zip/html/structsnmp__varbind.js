var structsnmp__varbind =
[
    [ "next", "structsnmp__varbind.html#a7388422ffb0607b209a39d6d3fcad40e", null ],
    [ "oid", "structsnmp__varbind.html#ace3a9e4dcdc9a5ec79a20c84946418a4", null ],
    [ "prev", "structsnmp__varbind.html#a365abcc1f80d28dc8ffd07193099c760", null ],
    [ "type", "structsnmp__varbind.html#ad63223e45e04c08ea97859b8ba767950", null ],
    [ "value", "structsnmp__varbind.html#a328227d7ae188a0a2feb95f8000aac45", null ],
    [ "value_len", "structsnmp__varbind.html#ab094577fac6c7cc16ad666c9970cdb85", null ]
];