var structlwip__select__cb =
[
    [ "exceptset", "structlwip__select__cb.html#a2a1e68993ed887fca326d1373ea6caed", null ],
    [ "next", "structlwip__select__cb.html#a94128f0e164f895226f20fe75fddd35a", null ],
    [ "poll_fds", "structlwip__select__cb.html#ae39fc1bef3938380d15085e0141639de", null ],
    [ "poll_nfds", "structlwip__select__cb.html#a39c4980c261380481f79af2b536ebfba", null ],
    [ "prev", "structlwip__select__cb.html#a21a98e316bb7001d8750b20f5a7d0aa7", null ],
    [ "readset", "structlwip__select__cb.html#a8694a2ce0dd5f91be84056982b96978e", null ],
    [ "sem", "structlwip__select__cb.html#ac9e790cac8b5eae607a8ef95dcc68482", null ],
    [ "sem_signalled", "structlwip__select__cb.html#a1c00f1159e9e8eb7cca02c497605cd99", null ],
    [ "writeset", "structlwip__select__cb.html#aa89638b1c2c6b2c88030560861aba04c", null ]
];