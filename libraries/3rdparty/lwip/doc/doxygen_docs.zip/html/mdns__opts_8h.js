var mdns__opts_8h =
[
    [ "MDNS_DEBUG", "group__mdns__opts.html#ga53a97502efdcf1214cab4078f93a6dc9", null ],
    [ "MDNS_MAX_SERVICES", "group__mdns__opts.html#ga82749ee08be21967b6daf577b9710ac6", null ],
    [ "MDNS_RESP_USENETIF_EXTCALLBACK", "group__mdns__opts.html#ga172e579cd09a1db51cf224319c012396", null ]
];