var group__sys__misc =
[
    [ "sys_init", "group__sys__misc.html#gaf411a8bc6b7ed4b0af9114e10c959448", null ],
    [ "sys_msleep", "group__sys__misc.html#ga6b8786f43e779953e8b74e983c88682e", null ],
    [ "sys_thread_new", "group__sys__misc.html#ga0d596afdd8dbcfad320172d39b0f607a", null ]
];