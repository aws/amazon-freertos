var http__client_8c =
[
    [ "HTTPC_CLIENT_AGENT", "http__client_8c.html#aeda6122d341b879ba8b0fb2df834276a", null ],
    [ "HTTPC_DEBUG", "http__client_8c.html#a32d4c0e6e42327e21fb59dabdc152dd1", null ],
    [ "HTTPC_DEBUG_REQUEST", "http__client_8c.html#ad2ec42c8e7adaef67266a5bd12c4ad2a", null ],
    [ "httpc_get_file", "group__httpc.html#ga6c961e52cec2d25b4b82b6910ebcfa1b", null ],
    [ "httpc_get_file_dns", "group__httpc.html#gabd4ef2259885a93090733235cc0fa8d6", null ]
];