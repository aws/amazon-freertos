var structnetvector =
[
    [ "len", "structnetvector.html#a8a95e6dcf57067e4354b9c2b6b391dbd", null ],
    [ "ptr", "structnetvector.html#a523362737ea7764f9aaa73a050a0b983", null ]
];