var structlwip__sock =
[
    [ "conn", "structlwip__sock.html#a3a3fee485b3361ed7054cde149355fb4", null ],
    [ "errevent", "structlwip__sock.html#a9245a7ab9471bfb6fac94c66d26fba5e", null ],
    [ "lastdata", "structlwip__sock.html#aa487ac16b7e5b6a2a618b7b5060247e1", null ],
    [ "rcvevent", "structlwip__sock.html#af40d67cbaef4318d26e560988b6e1b3a", null ],
    [ "select_waiting", "structlwip__sock.html#aadbcf5ec3d50631d8821200163d88d38", null ],
    [ "sendevent", "structlwip__sock.html#a7e282776681ea4b7bd389950a8a64fa8", null ]
];