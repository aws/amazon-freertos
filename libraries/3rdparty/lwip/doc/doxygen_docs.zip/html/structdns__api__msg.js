var structdns__api__msg =
[
    [ "addr", "structdns__api__msg.html#a217814594564077d21b0f2696280b2a8", null ],
    [ "dns_addrtype", "structdns__api__msg.html#afb2536a6c342bed4c4ad9d75982f7493", null ],
    [ "err", "structdns__api__msg.html#a6536d91adb146555461359bd451b30de", null ],
    [ "name", "structdns__api__msg.html#ada44a0eb6c9181cac80cfbbee01d3b53", null ],
    [ "sem", "structdns__api__msg.html#a15e01e675ebc46b5aede42342be445e2", null ]
];