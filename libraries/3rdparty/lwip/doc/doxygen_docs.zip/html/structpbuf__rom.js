var structpbuf__rom =
[
    [ "next", "structpbuf__rom.html#a5ffdf590ed65b217e2d96f648e1bd3e7", null ],
    [ "payload", "structpbuf__rom.html#a5cd0dcc590038629644ad775d76230a1", null ]
];