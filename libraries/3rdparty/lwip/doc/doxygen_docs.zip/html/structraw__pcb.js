var structraw__pcb =
[
    [ "mcast_ifindex", "structraw__pcb.html#a5124a21e1523c774bd76c0eabc7c7ca8", null ],
    [ "mcast_ttl", "structraw__pcb.html#a2ecc77e919de9bb552d1c70e771e2cad", null ],
    [ "recv", "structraw__pcb.html#a963b023239ad97c05536046ed7058a10", null ]
];